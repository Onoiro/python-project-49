### Hexlet tests and linter status:
[![Actions Status](https://github.com/Onoiro/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Onoiro/python-project-49/actions)

<a href="https://codeclimate.com/github/Onoiro/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2af138e68148eb88cd92/maintainability" /></a>
